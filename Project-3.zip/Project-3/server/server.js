const express = require('express');
const http = require('http');
const path = require('path');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

io.on('connection', function(socket) {
    socket.on('newuser', function(username) {
        socket.username = username;
        socket.broadcast.emit('update', `${username} joined the conversation`);
    });

    socket.on('exituser', function(username) {
        socket.broadcast.emit('update', `${username} left the conversation`);
    });

    socket.on('chat', function(message) {
        socket.broadcast.emit('chat', message);
    });

    socket.on('disconnect', () => {
        if (socket.username) {
            io.emit('update', `${socket.username} disconnected`);
        }
    });
});

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, "../Clients")));

server.listen(3000, () => {
    console.log('Server running on port 3000');
});
